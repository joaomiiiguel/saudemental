﻿using UnityEngine;

public class Level2D: MonoBehaviour {
  private string id_simul="simul_exemplo_cs";
  private string student_id="";
  private float mastery_score=0f;
  private int num_objective=0;
  private string msg="";
  private string tf_score="90.00";

  private void setStudentID(string studId) {
    this.student_id=studId;
    this.msg+="student_id: "+this.student_id+"\n";
  }
  private void setMastery(float value) {
    this.mastery_score=value;
    this.msg+="mastery_score: "+this.mastery_score+"\n";
  }
  private void setNumObjective(int valor) {
    this.num_objective=valor;
    this.msg+="num_objective: "+this.num_objective+"\n";
  }
  public void Start() {
    if(Application.isWebPlayer) {
      Application.ExternalEval("if(typeof api!='undefined') {\n"
       +"  unityObj.getUnity().SendMessage('/cameraMain','setStudentID',api.LMSGetValue('cmi.core.student_id'));\n"
       +"  unityObj.getUnity().SendMessage('/cameraMain','setMastery',parseFloat(api.LMSGetValue('cmi.student_data.mastery_score')));\n"
       +"  unityObj.getUnity().SendMessage('/cameraMain','setNumObjective',scorm_ativ_pos('"+this.id_simul+"'));\n"
       +"}\n");
    }
    else this.msg+="Somente é possível testar no WebPlayer!\n";
  }
  public void OnGUI() {
    float score;
    int tmp_min;
    int tmp_seg;
    string tmp_str;
    string str_report;

    GUI.Box(new Rect(10,10,Screen.width-20,95),"Exemplo de integração: Simulador Unity C# WebPlayer em SCORM");
    if(Application.isWebPlayer) {
      GUI.Label(new Rect(Screen.width-142,42,42,22),"Score:");
      this.tf_score=GUI.TextField(new Rect(Screen.width-100,42,80,22),this.tf_score,6);
      if(GUI.Button(new Rect(Screen.width-190,70,115,25),"salvar no scorm")) {
        score=float.Parse(this.tf_score);
        tmp_min=(int)Time.timeSinceLevelLoad/60;
        tmp_seg=(int)Time.timeSinceLevelLoad%60;
        tmp_str="00:"+(tmp_min<10?"0":"")+tmp_min+(tmp_seg<10?":0":":")+tmp_seg;
        str_report="<div style=\"font:normal 12px Arial,Helvetica,sans-serif;padding:7px;margin-bottom:10px;border:5px solid #CECECE;background:#E9E9E9\">\n"
         +"  <div style=\"font-size:18px;font-weight:bold;margin-bottom:5px\">Exemplo de integração: Simulador Unity C# WebPlayer em SCORM</div>\n"
         +"  <div style=\"border:1px solid #CECECE;background-color:#FFFFFF;padding:5px;margin:5px 0px\">\n"
         +"    <div style=\"font-size:14px;font-weight:bold;margin-bottom:5px\">RELATÓRIO DE AVALIAÇÃO DO SIMULADOR</div>\n"
         +"    Tempo de realização da tarefa: "+tmp_str+"<br/>\n"
         +"    Nota: "+score.ToString("f2")+"<br/>\n"
         +"    <div style=\"padding-top:5px\"><b>Em:</b> "+System.DateTime.Now.ToString("dd/MM/yyyy")
         +"     &nbsp;&nbsp;&nbsp;<b>Hora:</b> "+System.DateTime.Now.ToString("HH:mm:ss")+"</div>\n"
         +"  </div>\n"
         +"</div>\n";
        Application.ExternalCall("api.LMSSetValue","cmi.core.score.raw",score.ToString("f2")); // esta é a nota da UC
        Application.ExternalCall("api.LMSSetValue","cmi.core.session_time",tmp_str);
        Application.ExternalCall("api.LMSSetValue","cmi.objectives."+this.num_objective+".id",this.id_simul);
        Application.ExternalCall("api.LMSSetValue","cmi.objectives."+this.num_objective+".score.raw",score.ToString("f2")); // nota do simulador
        Application.ExternalCall("api.LMSSetValue","cmi.objectives."+this.num_objective+".status",(score < this.mastery_score ? "failed":"passed"));
        Application.ExternalCall("api.LMSSetValue","cmi.interactions."+this.num_objective+".id",this.id_simul);
        Application.ExternalCall("api.LMSSetValue","cmi.interactions."+this.num_objective+".objectives.0.id",this.id_simul);
        Application.ExternalCall("api.LMSSetValue","cmi.interactions."+this.num_objective+".time",System.DateTime.Now.ToString("HH:mm:ss"));
        Application.ExternalCall("api.LMSSetValue","cmi.interactions."+this.num_objective+".type","performance");
        Application.ExternalCall("api.LMSSetValue","cmi.interactions."+this.num_objective+".result",(score < this.mastery_score ? "wrong":"correct"));
        Application.ExternalCall("api.LMSSetValue","cmi.interactions."+this.num_objective+".latency",tmp_str);
        Application.ExternalCall("api.LMSSetValue","cmi.comments",str_report);
        Application.ExternalCall("api.LMSCommit",""); // o LMSFinish tranca as outras atividades
        this.msg+="Tarefa salva com sucesso:\n"
         +"* Tempo de realização da tarefa: "+tmp_str+"\n"
         +"* Nota: "+score.ToString("f2")+"\n";
      }
    }
    if(GUI.Button(new Rect(Screen.width-70,70,50,25),"sair")) {
      if(Application.isWebPlayer) Application.ExternalCall("scorm_ativ_fecha","");
      else Application.Quit();
    }
    GUI.Box(new Rect(10,115,Screen.width-20,Screen.height-125),this.msg);
  }
}
